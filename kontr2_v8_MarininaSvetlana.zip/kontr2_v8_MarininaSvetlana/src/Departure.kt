abstract class Departure:Depart
{
    abstract var marka:String
    abstract var pynkt_otp:String
    abstract var pynkt_naz:String
    abstract var date:String
    abstract var time_otp:Double
    abstract var time:Int
    override fun Get_Info()
    {
        println("Марка самолёта: ${this.marka}")
        println("Пункт отправления: ${this.pynkt_otp}")
        println("Пункт назначения: ${this.pynkt_naz}")
        println("Дата отправления: ${this.date}")
        println("Время отправления: ${this.time_otp}")
        println("Время в пути: ${this.time}")
    }
}