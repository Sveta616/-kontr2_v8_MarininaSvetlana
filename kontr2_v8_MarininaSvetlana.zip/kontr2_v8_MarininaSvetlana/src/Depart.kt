interface Depart {
fun Set_Info()
fun Get_Info()

}