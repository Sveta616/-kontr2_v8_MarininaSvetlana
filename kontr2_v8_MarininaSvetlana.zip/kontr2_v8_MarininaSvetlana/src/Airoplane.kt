import kotlinx.coroutines.delay
class Airoplane (
    override var marka:String,
    override var pynkt_otp:String,
    override var pynkt_naz:String,
    override var date:String,
    override var time_otp:Double,
    override var time:Int
    ):Departure()
{
        override fun Set_Info()
        {
            try {
                println("Введите марку самолёта")
                this.marka = readLine()!!.toString()
                println("Введите пункт отправления")
                this.pynkt_otp = readLine()!!.toString()
                println("Введите пункт назначения")
                this.pynkt_naz = readLine()!!.toString()
                println("Введите дату отправления")
                this.date = readLine()!!.toString()
                do {
                    println("Введите время отправления, разделяя часы от минут точкой")
                    this.time_otp = readLine()!!.toDouble()
                }while(this.time_otp<=0||this.time_otp>24)
                do{
                println("Введите время в пути в часах")
                this.time = readLine()!!.toInt()
                }while(this.time<=0||this.time>24)
            }catch(e:Exception)
            {
                println("Введите данные корректно")
            }

        }
    fun Price()
    {
        var pr:Double
        do {
            println("Введите цену за один рейс")
             pr = readLine()!!.toDouble()
        }while(pr<=0)
        do {
            println("Вы являетесь работником компании аэрофлота или воевавшим? Напишите (Да/Нет)")
            var otv = readLine()!!.toString()
            if(otv=="Да") {
                println("У вас следует скидка, мы ценим и заботимся о таких людях. Ваша цена за билет в итоге равна:${pr * 0.5} ")
            }
            else println("У вас рейс идет без скидки, ваша цена остаётся прежней ${pr}")
        }while(otv!="Да"&&otv!="Нет")
    }
    suspend fun Rais(n:Int)
    {
        try {
            var r = ""
            for (i in 0..n-1 ) {
                println("Введите рейс")
                r+= readLine()!!.toString()+ " "
                delay(800L)
            }
            println("Рейсы за сегодняшний день:$r")
        }catch(E:Exception)
        {
            println("Введите данные корректно")
        }
    }
    }




