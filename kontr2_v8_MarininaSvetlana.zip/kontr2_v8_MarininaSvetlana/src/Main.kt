import kotlinx.coroutines.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
suspend fun main()= coroutineScope {
    var airoplane=Airoplane("","","","",0.0,0)
    airoplane.Set_Info()
    airoplane.Get_Info()
    launch {
        var n:Int
        do{
         println("Введите кол-во рейсов")
         n= readLine()!!.toInt()
    }while(n<=0||n>20)
        airoplane.Rais(n)
    }
    delay(20000L)
    airoplane.Price()

}